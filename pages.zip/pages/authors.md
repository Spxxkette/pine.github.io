---
layout: pagedefault
title: "Authors"
permalink: /authors/
---

<!-- <div class="wordcloud">
	<img src="{{ site.baseurl }}/assets/img/bannerauthors.png"></div>
<div>-->
<head>
    <link rel="stylesheet" type="text/css" href="{{site.baseurl}}/assets/css/includes-style/browse-author-style.css">
    </head>
	
For each of the **{{site.data.biography | size}}+ authors** in our continuously growing dataset! They all have a profile that contains a brief biographical summary, with links to the author's <a href="https://www.wikipedia.org/" target="_blank">Wikipedia page</a> and various <a href="https://www.dloc.com/" target="_blank">DLOC resources</a>. The author bibliography is displayed as a scrollable vertical timeline in ascending order of publication.

Author profiles generally include new editions, translations and significant reprints of their original works.

###### Directions

Clicking on Read More would lead you to the author's profile.Clicking below.

<div class="authors">
{% include updated-browse-authors.html %}
</div>
